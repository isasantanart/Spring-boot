package com.devsenai1a.conversorMoeda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConversorMoedaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConversorMoedaApplication.class, args);
	}

}
